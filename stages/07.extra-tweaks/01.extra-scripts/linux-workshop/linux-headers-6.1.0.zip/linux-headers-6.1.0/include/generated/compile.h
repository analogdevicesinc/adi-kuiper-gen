#define UTS_MACHINE		"arm"
#define LINUX_COMPILE_BY	"root"
#define LINUX_COMPILE_HOST	"CHEGBELI-L03"
#define LINUX_COMPILER		"gcc (Debian 12.2.0-14) 12.2.0, GNU ld (GNU Binutils for Debian) 2.40"
