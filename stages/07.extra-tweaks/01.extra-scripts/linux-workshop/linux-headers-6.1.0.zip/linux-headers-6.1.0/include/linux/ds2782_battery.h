/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __LINUX_DS2782_BATTERY_H
#define __LINUX_DS2782_BATTERY_H

struct ds278x_platform_data {
	int rsns;
};

#endif
