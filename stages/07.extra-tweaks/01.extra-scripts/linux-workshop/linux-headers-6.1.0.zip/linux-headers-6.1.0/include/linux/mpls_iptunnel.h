/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _LINUX_MPLS_IPTUNNEL_H
#define _LINUX_MPLS_IPTUNNEL_H

#include <uapi/linux/mpls_iptunnel.h>

#endif  /* _LINUX_MPLS_IPTUNNEL_H */
