/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _INCLUDE_LIBFDT_H_
#define _INCLUDE_LIBFDT_H_

#include <linux/libfdt_env.h>
#include "../../scripts/dtc/libfdt/libfdt.h"

#endif /* _INCLUDE_LIBFDT_H_ */
