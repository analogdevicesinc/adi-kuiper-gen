/* SPDX-License-Identifier: GPL-2.0 */
#ifndef	_CM4000_H_
#define	_CM4000_H_

#include <uapi/linux/cm4000_cs.h>


#define	DEVICE_NAME		"cmm"
#define	MODULE_NAME		"cm4000_cs"

#endif	/* _CM4000_H_ */
