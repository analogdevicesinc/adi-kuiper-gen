#ifndef _LINUX_SEG6_LOCAL_H
#define _LINUX_SEG6_LOCAL_H

#include <uapi/linux/seg6_local.h>

#endif
